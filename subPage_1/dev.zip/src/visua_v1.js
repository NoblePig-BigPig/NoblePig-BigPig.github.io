function processImages() {
    const file1 = document.getElementById('image1').files[0];
    const file2 = document.getElementById('image2').files[0];
    
    if (!file1 || !file2) {
        alert('請選擇兩張圖片');
        return;
    }
  
    const originalCanvas1 = document.getElementById('originalCanvas1');
    const originalCanvas2 = document.getElementById('originalCanvas2');
    const diffCanvas = document.getElementById('diffCanvas');
    const ctx1 = originalCanvas1.getContext('2d');
    const ctx2 = originalCanvas2.getContext('2d');
    const diffCtx = diffCanvas.getContext('2d');
  
    const img1 = new Image();
    const img2 = new Image();
  
    img1.onload = function() {
        originalCanvas1.width = img1.width;
        originalCanvas1.height = img1.height;
        ctx1.drawImage(img1, 0, 0);
    };
  
    img2.onload = function() {
        originalCanvas2.width = img2.width;
        originalCanvas2.height = img2.height;
        ctx2.drawImage(img2, 0, 0);
  
        if (img1.width !== img2.width || img1.height !== img2.height) {
            alert('兩張圖片大小必須相同');
            return;
        }
  
        // 比較圖片
        const imageData1 = ctx1.getImageData(0, 0, img1.width, img1.height);
        const imageData2 = ctx2.getImageData(0, 0, img2.width, img2.height);
  
        // 儲存異常像素位置
        const diffPixels = [];
        let minX = img1.width, maxX = 0, minY = img1.height, maxY = 0;
  
        for (let y = 0; y < img1.height; y++) {
            for (let x = 0; x < img1.width; x++) {
                const index = (y * img1.width + x) * 4;
                const isDiff = 
                    imageData1.data[index] !== imageData2.data[index] || 
                    imageData1.data[index+1] !== imageData2.data[index+1] || 
                    imageData1.data[index+2] !== imageData2.data[index+2];
  
                if (isDiff) {
                    diffPixels.push({x, y});
                    
                    // 更新邊界
                    minX = Math.min(minX, x);
                    maxX = Math.max(maxX, x);
                    minY = Math.min(minY, y);
                    maxY = Math.max(maxY, y);
                }
            }
        }
  
        // 設置差異圖Canvas
        diffCanvas.width = img1.width;
        diffCanvas.height = img1.height;
        diffCtx.drawImage(img2, 0, 0); // 預設顯示第二張圖
  
        // 計算中心點
        const centerX = (minX + maxX) / 2;
        const centerY = (minY + maxY) / 2;
  
        // 計算半徑
        const radiusX = (maxX - minX) / 2;
        const radiusY = (maxY - minY) / 2;
        const radius = Math.max(radiusX, radiusY) + 10;
  
        // 在差異圖上畫圓
        if (diffPixels.length > 0) {
            diffCtx.beginPath();
            diffCtx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
            diffCtx.strokeStyle = 'yellow';
            diffCtx.lineWidth = 3;
            diffCtx.setLineDash([5, 5]); // 虛線
            diffCtx.stroke();
        }
  
        // 顯示差異百分比
        const diffPercentage = (diffPixels.length / (img1.width * img1.height)) * 100;
        console.log(`差異像素百分比: ${diffPercentage.toFixed(2)}%`);
    };
  
    img1.src = URL.createObjectURL(file1);
    img2.src = URL.createObjectURL(file2);
  }